# ----------------------------------------------------------
# IT533 - Processing Data in Files Assignment
# Author: Nicholas Summerlee
# Week 3 – Chapters 8 & 9
# ----------------------------------------------------------
# 1. Create an empty list called "sales_data"
# 2. Open SalesJan2009.csv and process line by line
# 3. Clean extra quotes
# 4. Create a dictionary for each record
# 5. Append each dictionary to sales_data
# 6. Write all data to transaction_data.json
# ----------------------------------------------------------

import json

# Create an empty list
sales_data = []

# Open the CSV file
f = open("SalesJan2009.csv", "r")

# Skip header row
header = f.readline()

#  Process each line
for line in f:
    # Split by comma
    parts = line.strip().split(",")

    # Clean and assign values
    transaction = {
        "Transaction_date": parts[0].replace('"', ''),
        "Product": parts[1].replace('"', ''),
        "Price": parts[2].replace('"', ''),
        "Payment_Type": parts[3].replace('"', ''),
        "Name": parts[4].replace('"', ''),
        "City": parts[5].replace('"', ''),
        "State": parts[6].replace('"', ''),
        "Country": parts[7].replace('"', '')
    }

    # Append dictionary to list
    sales_data.append(transaction)

f.close()

# Save to JSON file
out = open("transaction_data.json", "w")
json.dump(sales_data, out, indent=4)
out.close()

print("✅ Finished converting SalesJan2009.csv to transaction_data.json")
